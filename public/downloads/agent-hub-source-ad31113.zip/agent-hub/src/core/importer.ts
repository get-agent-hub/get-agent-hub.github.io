import { isRecord } from './values.js';
import { applicationOwner, CODEX_POLICY_KEYS } from '../adapters/policies.js';
import { fingerprint } from './mcp.js';
import type { HubServer } from './registry.js';
import { hasUrlCredentials, isInlineSecret, isSecretKey } from './secrets.js';
import type { ClientId, RawMcp } from './types.js';
import { fileURLToPath } from 'node:url';

/** Client-specific keys carried into `clients.<id>` instead of the shared definition. */
const PASSTHROUGH: Record<ClientId, string[]> = {
  'claude-code': [],
  codex: CODEX_POLICY_KEYS,
  dsh: [],
};

/** Recognize generated launchers even after moving the package or upgrading Node. */
export function isHubProjection(raw: Record<string, unknown>): boolean {
  const cmd = String(raw.command ?? '');
  const args = (raw.args as unknown[] | undefined)?.map(String) ?? [];
  const cli = fileURLToPath(new URL('../../dist/cli.js', import.meta.url));
  const namedLauncher =
    /(?:^|[\\/])(ahub|agent-hub)(?:\.cmd|\.exe)?$/i.test(cmd) &&
    args[0] === 'mcp' &&
    args[1] === 'run';
  const nodeLauncher = args[0] === cli && args[1] === 'mcp' && args[2] === 'run';
  const markedLauncher =
    isRecord(raw.env) &&
    typeof raw.env.AGENT_HUB_HOME === 'string' &&
    args.length === 4 &&
    args[1] === 'mcp' &&
    args[2] === 'run';
  return namedLauncher || nodeLauncher || markedLauncher;
}

export function normalize(client: ClientId, raw: Record<string, unknown>): HubServer {
  const s: HubServer = {};
  const type = String(raw.type ?? raw.transport ?? '').toLowerCase();
  if (raw.command) s.command = String(raw.command);
  if (Array.isArray(raw.args) && raw.args.length) s.args = raw.args.map(String);
  if (raw.cwd) s.cwd = String(raw.cwd);
  const env = raw.env as Record<string, unknown> | undefined;
  if (env && Object.keys(env).length)
    s.env = Object.fromEntries(Object.entries(env).map(([k, v]) => [k, String(v)]));
  const url = (raw.url ?? raw.serverUrl) as string | undefined;
  if (url) s.url = url;
  const headers = (raw.headers ?? raw.http_headers) as Record<string, unknown> | undefined;
  if (headers && Object.keys(headers).length)
    s.headers = Object.fromEntries(Object.entries(headers).map(([k, v]) => [k, String(v)]));
  if (raw.bearer_token_env_var)
    s.headers = { ...s.headers, Authorization: `Bearer \${${String(raw.bearer_token_env_var)}}` };
  if (type === 'sse') s.transport = 'sse';
  else if (!s.command && s.url) s.transport = 'http';

  const pass = Object.fromEntries(
    PASSTHROUGH[client].filter((k) => k in raw).map((k) => [k, raw[k]]),
  );
  if (Object.keys(pass).length) s.clients = { [client]: pass };
  const owner = applicationOwner(raw);
  if (owner) s.only = [owner];
  return s;
}

/** Fingerprint of the shared part only (ignores client passthrough and projection hints). */
export function coreFingerprint(s: HubServer): string {
  const { health: _h, clients: _c, only: _o, tags: _t, ...core } = s;
  return fingerprint(core as Record<string, unknown>);
}

export interface Candidate {
  client: ClientId;
  source: string;
  server: HubServer;
}

export interface MergeResult {
  name: string;
  server?: HubServer;
  from: ClientId[];
  conflict?: Candidate[];
}

/** Group candidates by identical core config. Identical → merged; different → conflict (resolved by `prefer`). */
export function merge(name: string, cands: Candidate[], prefer: ClientId[]): MergeResult {
  const groups = new Map<string, Candidate[]>();
  for (const c of cands) {
    const fp = coreFingerprint(c.server);
    groups.set(fp, [...(groups.get(fp) ?? []), c]);
  }
  let chosen: Candidate[];
  if (groups.size === 1) chosen = [...groups.values()][0];
  else {
    const pick = prefer
      .map((p) => [...groups.values()].find((g) => g.some((c) => c.client === p)))
      .find(Boolean);
    if (!pick) return { name, from: [], conflict: cands };
    chosen = pick;
  }
  const base: HubServer = structuredClone(chosen[0].server);
  for (const c of chosen.slice(1)) {
    if (c.server.clients) base.clients = { ...base.clients, ...c.server.clients };
  }
  // passthrough from non-chosen variants is still client-specific and safe to keep
  for (const c of cands)
    if (!chosen.includes(c) && c.server.clients)
      base.clients = { ...c.server.clients, ...base.clients };
  // a server present only in one client and managed by it stays restricted; otherwise project everywhere
  return {
    name,
    server: base,
    from: chosen.map((c) => c.client),
    conflict: groups.size > 1 ? cands : undefined,
  };
}

export function collectCandidates(
  raws: { client: ClientId; items: RawMcp[] }[],
): Map<string, Candidate[]> {
  const byName = new Map<string, Candidate[]>();
  for (const { client, items } of raws) {
    for (const r of items) {
      if (isHubProjection(r.raw)) continue;
      const c: Candidate = { client, source: r.source, server: normalize(client, r.raw) };
      byName.set(r.name, [...(byName.get(r.name) ?? []), c]);
    }
  }
  return byName;
}

// ---------------------------------------------------------------- secret extraction

const envName = (value: string): string => {
  const normalized = value
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return /^[A-Z_]/.test(normalized) ? normalized : `_${normalized}`;
};

export interface Extracted {
  server: HubServer;
  /** var name → secret value (to be written to .env) */
  secrets: Map<string, string>;
  /** human-readable list of what was replaced (no values) */
  replaced: string[];
}

/**
 * Replace literal secrets with ${VAR} references.
 * `taken` = vars already in .env (name → value); a name is reused only if the value matches.
 */
export function extractSecrets(
  name: string,
  input: HubServer,
  taken: Map<string, string>,
): Extracted {
  const server = structuredClone(input);
  const secrets = new Map<string, string>();
  const replaced: string[] = [];
  const prefix = envName(name);

  const claim = (preferred: string, value: string): string => {
    for (const cand of [preferred, `${prefix}_${preferred}`]) {
      const have = taken.get(cand) ?? secrets.get(cand);
      if (have === undefined || have === value) {
        secrets.set(cand, value);
        return cand;
      }
    }
    let i = 2;
    while (taken.has(`${prefix}_${preferred}_${i}`) || secrets.has(`${prefix}_${preferred}_${i}`))
      i++;
    const v = `${prefix}_${preferred}_${i}`;
    secrets.set(v, value);
    return v;
  };

  for (const [k, v] of Object.entries(server.env ?? {})) {
    if (isInlineSecret(k, v)) {
      server.env![k] = `\${${claim(envName(k), v)}}`;
      replaced.push(`env.${k}`);
    }
  }

  for (const [k, v] of Object.entries(server.headers ?? {})) {
    if (!isInlineSecret(k, v)) continue;
    const bearer = /^(Bearer|Basic|Token)\s+(.+)$/i.exec(v);
    const value = bearer ? bearer[2] : v;
    const ref = `\${${claim(`${prefix}_${envName(k)}`.replace(`${prefix}_${prefix}_`, `${prefix}_`), value)}}`;
    server.headers![k] = bearer ? `${bearer[1]} ${ref}` : ref;
    replaced.push(`headers.${k}`);
  }

  if (server.url && hasUrlCredentials(server.url)) {
    replaced.push('url');
    server.url = `\${${claim(`${prefix}_URL`, server.url)}}`;
  }
  if (server.url && !server.url.startsWith('${')) {
    const u = new URL(server.url);
    let changed = false;
    for (const [k, v] of u.searchParams) {
      if (isSecretKey(k) && v && !v.startsWith('${')) {
        u.searchParams.set(k, `\${${claim(`${prefix}_${envName(k)}`, v)}}`);
        replaced.push(`url?${k}`);
        changed = true;
      }
    }
    if (changed) server.url = decodeURI(u.toString());
  }

  if (server.args) {
    server.args = server.args.map((a, i, arr) => {
      const eq = /^(--?[A-Za-z0-9_-]+)=(.+)$/.exec(a);
      if (eq && isInlineSecret(eq[1], eq[2])) {
        replaced.push(`args ${eq[1]}`);
        return `${eq[1]}=\${${claim(`${prefix}_${envName(eq[1])}`, eq[2])}}`;
      }
      const prev = arr[i - 1];
      if (
        prev &&
        /^--?[A-Za-z]/.test(prev) &&
        !prev.includes('=') &&
        isSecretKey(prev) &&
        isInlineSecret(prev, a)
      ) {
        replaced.push(`args ${prev}`);
        return `\${${claim(`${prefix}_${envName(prev)}`, a)}}`;
      }
      if (hasUrlCredentials(a)) {
        replaced.push(`args.${i}`);
        return `\${${claim(`${prefix}_ARG_${i}`, a)}}`;
      }
      return a;
    });
  }

  return { server, secrets, replaced };
}

/** Final guard: any literal that still looks like a secret. Returns offending paths. */
export function findLeftoverSecrets(s: HubServer): string[] {
  const bad: string[] = [];
  for (const [k, v] of Object.entries(s.env ?? {})) if (isInlineSecret(k, v)) bad.push(`env.${k}`);
  for (const [k, v] of Object.entries(s.headers ?? {}))
    if (isInlineSecret(k, v)) bad.push(`headers.${k}`);
  for (const a of s.args ?? []) if (isInlineSecret('', a)) bad.push(`args`);
  if (s.url && hasUrlCredentials(s.url)) bad.push('url');
  return bad;
}
